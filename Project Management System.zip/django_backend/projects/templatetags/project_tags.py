from django import template
from ..models import Notification

register = template.Library()

@register.filter
def status_color(status):
    colors = {
        'جديد': 'primary',
        'قيد التنفيذ': 'warning',
        'معلق': 'danger',
        'مكتمل': 'success'
    }
    return colors.get(status, 'secondary')

@register.filter
def priority_color(priority):
    colors = {
        'منخفض': 'success',
        'متوسط': 'warning',
        'عالي': 'danger'
    }
    return colors.get(priority, 'secondary')

@register.simple_tag
def get_notifications(user):
    return user.notifications.all()[:5]

@register.simple_tag
def get_unread_notifications_count(user):
    return Notification.objects.filter(recipient=user, is_read=False).count()

@register.simple_tag
def get_latest_notifications(user):
    return Notification.objects.filter(recipient=user).order_by('-created_at')[:5]

@register.filter
def remaining_days_display(days):
    if not days:
        return "غير محدد"
    
    days = int(days.days)
    if days < 0:
        return f"متأخر بـ {abs(days)} يوم"
    elif days == 0:
        return "اليوم"
    else:
        return f"متبقي {days} يوم"

@register.simple_tag
def get_unread_chat_messages(user, project):
    return Notification.objects.filter(
        recipient=user,
        notification_type='new_message',
        related_project=project,
        is_read=False
    ).count()