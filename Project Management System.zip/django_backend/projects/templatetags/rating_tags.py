from django import template
from django.db.models import Count

register = template.Library()

@register.filter
def rating_percentage(task, rating):
    """
    حساب النسبة المئوية لكل تقييم
    """
    total = task.ratings.count()
    if total > 0:
        count = task.ratings.filter(rating=rating).count()
        return (count / total) * 100
    return 0

@register.filter
def rating_count(task, rating):
    """
    حساب عدد التقييمات لكل نجمة
    """
    return task.ratings.filter(rating=rating).count()