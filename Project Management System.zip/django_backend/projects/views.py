from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Project, Task, Comment, Notification, TaskRating, TaskAttachment, ChatRoom, Message, ProjectRole
from .forms import ProjectForm, TaskForm, CommentForm, TaskAssignForm, TaskRatingForm
from django.utils import timezone
from datetime import datetime, timedelta
from django.db.models import Q, Count, F, ExpressionWrapper, DurationField, Value
import pandas as pd
from django.http import HttpResponse, JsonResponse
from .utils import create_notification
from django.contrib.auth.models import User
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from django.urls import reverse
import os
from django.http import HttpResponseRedirect
from .permissions import ROLE_PERMISSIONS
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
import json
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt

@login_required
def project_list(request):
    try:
        # الحصول على جميع المشاريع التي يمكن للمستخدم الوصول إليها
        projects = Project.objects.filter(
            Q(created_by=request.user) |
            Q(members=request.user)
        ).distinct()

        # تطبيق البحث
        search_query = request.GET.get('search', '')
        if search_query:
            projects = projects.filter(
                Q(name__icontains=search_query) |
                Q(description__icontains=search_query)
            )

        # تطبيق تصفية الحالة
        status = request.GET.get('status', '')
        if status:
            projects = projects.filter(status=status)

        return render(request, 'projects/project_list.html', {
            'projects': projects,
            'search_query': search_query,
            'current_status': status
        })
    except Exception as e:
        print(f"Error in project_list view: {str(e)}")  # للتشخيص
        messages.error(request, f"حدث خطأ: {str(e)}")
        return render(request, 'projects/project_list.html', {
            'projects': [],
            'error': str(e)
        })

@login_required
def project_create(request):
    """إنشاء مشروع جديد"""
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            try:
                project = form.save(commit=False)
                project.created_by = request.user
                project.save()
                
                # إنشاء دور المالك للمستخدم لحالي
                ProjectRole.objects.create(
                    project=project,
                    user=request.user,
                    role='مالك'
                )
                
                # إضافة الأعضاء المحددين (باستثناء المالك)
                members = form.cleaned_data.get('members', [])
                for member in members:
                    if member != request.user:
                        ProjectRole.objects.create(
                            project=project,
                            user=member,
                            role='عضو'
                        )
                
                form.save_m2m()
                messages.success(request, 'تم إنشاء المشروع بنجاح!')
                return redirect('projects:project_detail', pk=project.pk)
                
            except Exception as e:
                messages.error(request, f'حدث خطأ أثناء إنشاء المشروع: {str(e)}')
                return redirect('projects:project_list')
    else:
        form = ProjectForm()
    
    return render(request, 'projects/project_form.html', {
        'form': form,
        'title': 'إنشاء مشروع جديد'
    })

def filter_and_search_tasks(tasks, status, priority, search_query):
    if status:
        tasks = tasks.filter(status=status)
    if priority:
        tasks = tasks.filter(priority=priority)
    if search_query:
        tasks = tasks.filter(
            Q(title__icontains=search_query) |
            Q(description__icontains=search_query)
        )
    return tasks

@login_required
def project_detail(request, pk):
    project = get_object_or_404(Project, pk=pk)
    
    # حساب عدد الرسائل غير المقروءة
    unread_messages_count = Notification.objects.filter(
        recipient=request.user,
        notification_type='new_message',
        related_project=project,
        is_read=False
    ).count()
    
    # التحقق من صلاحية الوصول
    if not request.user.is_superuser:
        project_role = ProjectRole.objects.filter(
            project=project,
            user=request.user
        ).first()
        
        if not (project_role or (project.created_by and project.created_by == request.user)):
            messages.error(request, f'ليس لديك صلاحية الوصول لمشروع "{project.name}"')
            return redirect('projects:project_list')
    else:
        project_role = type('ProjectRole', (), {
            'role': 'مالك',
            'permissions': ROLE_PERMISSIONS['مالك']
        })
    
    # البحث والتصفية
    search_query = request.GET.get('search', '')
    status = request.GET.get('status', '')
    
    tasks = project.tasks.all()
    tasks = filter_and_search_tasks(tasks, status, None, search_query)
    
    return render(request, 'projects/project_detail.html', {
        'project': project,
        'tasks': tasks,
        'search_query': search_query,
        'status': status,
        'project_role': project_role,
        'unread_messages_count': unread_messages_count,
    })

@login_required
def task_create(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.project = project
            task.save()
            
            # إنشاء إشعار للمستخدم المعين للمهمة
            assigned_to = form.cleaned_data.get('assigned_to')
            if assigned_to:
                create_notification(
                    recipient=assigned_to,
                    notification_type='task_assigned',
                    title='تم تعيينك لمهمة جديدة',
                    message=f'تم تعيينك لمهمة جديدة "{task.title}" في مشروع "{project.name}"',
                    related_task=task
                )
                print(f"تم إنشاء إشعار للمستخدم {assigned_to.username}")  # للتأكد من إنشاء الإشعار
            
            messages.success(request, 'تم إنشاء المهمة بنجاح!')
            return redirect('projects:project_detail', pk=project_id)
    else:
        form = TaskForm()
    
    return render(request, 'projects/task_form.html', {
        'form': form,
        'project': project
    })

@login_required
def task_edit(request, project_id, task_id):
    project = get_object_or_404(Project, id=project_id)
    task = get_object_or_404(Task, id=task_id, project=project)
    
    if request.method == 'POST':
        previous_data = {
            'title': task.title,
            'description': task.description,
            'status': task.get_status_display(),
            'priority': task.get_priority_display(),
            'due_date': task.due_date,
            'assigned_to': task.assigned_to
        }
        
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            task = form.save()
            
            # تحقق من تغيير أي حقل من حقول المهمة
            fields_changed = []
            if task.title != previous_data['title']:
                fields_changed.append('العنوان')
            if task.description != previous_data['description']:
                fields_changed.append('الوصف')
            if task.get_status_display() != previous_data['status']:
                fields_changed.append('الحالة')
            if task.get_priority_display() != previous_data['priority']:
                fields_changed.append('الأولوية')
            if task.due_date != previous_data['due_date']:
                fields_changed.append('تاريخ الاستحقاق')
            if task.assigned_to != previous_data['assigned_to']:
                fields_changed.append('المسؤول')
            
            # إنشاء إشعار إذا تم تغيير أي من البيانات
            if fields_changed and task.assigned_to:
                create_notification(
                    recipient=task.assigned_to,
                    notification_type='task_updated',
                    title='تم تحديث المهمة المسندة إليك',
                    message=f'تم تحديث المهمة "{task.title}": تم تغيير {" و ".join(fields_changed)}',
                    related_task=task
                )
            
            messages.success(request, 'تم تحديث المهمة بناح!')
            return redirect('projects:project_detail', pk=project.id)
    else:
        form = TaskForm(instance=task)
    
    return render(request, 'projects/task_form.html', {
        'form': form,
        'project': project,
        'task': task,
        'title': 'تعديل المهمة'
    })

@login_required
def project_tasks_filter(request, project_id, status=None):
    """تصفية المهام حسب الحالة"""
    project = get_object_or_404(Project, id=project_id)
    tasks = project.tasks.all()
    
    if status:
        tasks = tasks.filter(status=status)
    
    # حساب الإحصائيات
    total_tasks = project.tasks.count()
    completed_tasks = project.tasks.filter(status='مكتمل').count()
    in_progress_tasks = project.tasks.filter(status='قيد_التنفيذ').count()
    progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    
    context = {
        'project': project,
        'tasks': tasks,
        'progress': round(progress, 1),
        'completed_tasks': completed_tasks,
        'in_progress_tasks': in_progress_tasks,
        'current_status': status
    }
    
    if request.headers.get('HX-Request'):
        return render(request, 'projects/partials/task_list.html', context)
    return render(request, 'projects/project_detail.html', context)

@login_required
def task_delete(request, project_id, task_id):
    project = get_object_or_404(Project, id=project_id)
    task = get_object_or_404(Task, id=task_id, project=project)
    
    if request.method == 'POST':
        task.delete()
        messages.success(request, 'تم حذف المهمة بنجاح')
        return redirect('projects:project_detail', pk=project.id)
    
    return redirect('projects:project_detail', pk=project.id)

@login_required
def export_tasks_to_excel(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    
    if request.method == 'POST':
        selected_tasks = request.POST.getlist('selected_tasks')
        tasks = project.tasks.filter(id__in=selected_tasks)
    else:
        tasks = project.tasks.all()
    
    data = {
        'العنوان': [task.title for task in tasks],
        'الوصف': [task.description for task in tasks],
        'المسؤول': [task.assigned_to.get_full_name() if task.assigned_to else '' for task in tasks],
        'الحالة': [task.get_status_display() for task in tasks],
        'الأولوية': [task.get_priority_display() for task in tasks],
        'تايخ الاستحقاق': [task.due_date for task in tasks],
    }
    
    df = pd.DataFrame(data)
    
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = f'attachment; filename={project.name}_tasks.xlsx'
    
    df.to_excel(response, index=False, engine='openpyxl')
    
    return response

@login_required
def project_dashboard(request, pk):
    project = get_object_or_404(Project, pk=pk)
    tasks = project.tasks.all()
    today = timezone.now().date()
    
    # الإصائيات الأساسية
    stats = {
        'total_tasks': tasks.count(),
        'completed_tasks': tasks.filter(status='مكتمل').count(),
        'in_progress_tasks': tasks.filter(status='قيد_التنفيذ').count(),
        'new_tasks': tasks.filter(status='جديد').count(),
        'overdue_tasks': tasks.filter(due_date__lt=today, status__in=['جديد', 'قد_التنفيذ']).count(),
        'days_remaining': (project.end_date - today).days if project.end_date else None,
    }
    
    # توزيع المهام حسب الحالة مع الترجمة
    status_distribution = tasks.values('status').annotate(count=Count('id'))
    status_mapping = {
        'جديد': 'جديد',
        'قيد_التنفيذ': 'قيد التنفيذ',
        'متمل': 'مكتمل',
        'ملق': 'معلق'
    }
    status_distribution = [
        {'status': status_mapping.get(item['status'], item['status']), 'count': item['count']}
        for item in status_distribution
    ]
    
    # توزي المهام حسب الأولوية مع الترجمة
    priority_distribution = tasks.values('priority').annotate(count=Count('id'))
    priority_mapping = {
        'منخفض': 'منخفض',
        'متوسط': 'متوسط',
        'عالي': 'عالي'
    }
    priority_distribution = [
        {'priority': priority_mapping.get(item['priority'], item['priority']), 'count': item['count']}
        for item in priority_distribution
    ]
    
    context = {
        'project': project,
        'stats': stats,
        'status_distribution': status_distribution,
        'priority_distribution': priority_distribution,
        'overdue_tasks': tasks.filter(due_date__lt=today, status__in=['جديد', 'قيد_التنفيذ'])[:5],
        'upcoming_tasks': tasks.filter(due_date__gte=today, status__in=['جديد', 'قيد_التنفيذ']).order_by('due_date')[:5],
        'recent_tasks': tasks.order_by('-created_at')[:5],
    }
    
    return render(request, 'projects/project_dashboard.html', context)

@login_required
def task_comments(request, project_id, task_id):
    project = get_object_or_404(Project, id=project_id)
    task = get_object_or_404(Task, id=task_id, project=project)
    user_rating = TaskRating.objects.filter(task=task, user=request.user).first()
    comments = task.comments.select_related('author').all()
    
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.task = task
            comment.author = request.user
            comment.save()
            
            # إنشاء إشعار للمسؤول عن المهمة
            if task.assigned_to and task.assigned_to != request.user:
                create_notification(
                    recipient=task.assigned_to,
                    notification_type='comment',
                    title='تعليق جديد على مهمتك',
                    message=f'قام {request.user.get_full_name() or request.user.username} بالتعليق على المهمة: {task.title}',
                    related_task=task
                )
            
            # إنشاء إشعارات لجميع المعلقين السابقين
            previous_commenters = Comment.objects.filter(task=task)\
                .exclude(author=request.user)\
                .values_list('author', flat=True)\
                .distinct()
            
            for commenter_id in previous_commenters:
                commenter = User.objects.get(id=commenter_id)
                create_notification(
                    recipient=commenter,
                    notification_type='comment',
                    title='تعليق جديد على مهمة قمت بالتعليق عيها',
                    message=f'قام {request.user.get_full_name() or request.user.username} بالتعليق على المهمة: {task.title}',
                    related_task=task
                )
            
            messages.success(request, 'تم إضافة التعليق بنجاح!')
            return redirect('projects:task_comments', project_id=project_id, task_id=task_id)
    else:
        form = CommentForm()
    
    return render(request, 'projects/task_comments.html', {
        'project': project,
        'task': task,
        'comments': comments,
        'form': form,
        'user_rating': user_rating
    })

@login_required
def add_comment(request, project_id, task_id):
    task = get_object_or_404(Task, id=task_id, project_id=project_id)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            comment = form.save(commit=False)
            comment.task = task
            comment.author = request.user
            comment.save()
            
            # إنشاء إشعار للمسؤول عن المهمة
            if task.assigned_to and task.assigned_to != request.user:
                create_notification(
                    recipient=task.assigned_to,
                    notification_type='comment',
                    title='تعليق ديد عل مهمتك',
                    message=f'قا {request.user.get_full_name() or request.user.username} بالتعليق على المهمة: {task.title}',
                    related_task=task
                )
            
            # إنشاء إشعارات لجميع المعلقين السابقين (باستناء المعلق الحالي)
            previous_commenters = Comment.objects.filter(task=task)\
                .exclude(author=request.user)\
                .values_list('author', flat=True)\
                .distinct()
            
            for commenter_id in previous_commenters:
                commenter = User.objects.get(id=commenter_id)
                create_notification(
                    recipient=commenter,
                    notification_type='comment',
                    title='تعلق جديد على همة قمت بالتعليق عليها',
                    message=f'قم {request.user.get_full_name() or request.user.username} بالتعليق على المهمة: {task.title}',
                    related_task=task
                )
            
            messages.success(request, 'تم إضافة التعليق بنجاح')
            return redirect('projects:task_comments', project_id=project_id, task_id=task_id)

@login_required
def delete_comment(request, project_id, task_id, comment_id):
    project = get_object_or_404(Project, id=project_id)
    task = get_object_or_404(Task, id=task_id, project=project)
    comment = get_object_or_404(Comment, id=comment_id, task=task)
    
    # الحقق من أن المستخدم هو صاحب التعليق
    if comment.author == request.user:
        if request.method == 'POST':
            comment.delete()
            messages.success(request, 'تم حذف التعليق بنجاح!')
    else:
        messages.error(request, 'لا يمكنك حذف تعليق شخص آخر!')
    return redirect('projects:task_comments', project_id=project_id, task_id=task_id)

@login_required
def notification_list(request):
    notifications = Notification.objects.filter(recipient=request.user).order_by('-created_at')
    unread_count = notifications.filter(is_read=False).count()
    return render(request, 'projects/notification_list.html', {
        'notifications': notifications,
        'unread_count': unread_count
    })

@login_required
def mark_notification_read(request, pk):
    notification = get_object_or_404(Notification, pk=pk, recipient=request.user)
    notification.is_read = True
    notification.save()
    return redirect('projects:notification_list')

@login_required
def mark_all_notifications_read(request):
    request.user.notifications.filter(is_read=False).update(is_read=True)
    return redirect('projects:notification_list')

@login_required
def task_assign(request, project_id, task_id):
    task = get_object_or_404(Task, id=task_id, project_id=project_id)
    if request.method == 'POST':
        previous_assignee = task.assigned_to
        form = TaskAssignForm(request.POST, instance=task)
        if form.is_valid():
            task = form.save()
            
            # إنشاء إشعار للمستخدم الجديد المعين للمهمة
            if task.assigned_to and task.assigned_to != previous_assignee:
                create_notification(
                    recipient=task.assigned_to,
                    notification_type='task_assigned',
                    title='تم تعيينك لمهمة جديدة',
                    message=f'تم عييك للمهمة "{task.title}" في مشروع "{task.project.name}"',
                    related_task=task
                )
                messages.success(request, 'تم تعيين المهمة بنجاح!')
            return redirect('projects:project_detail', pk=project_id)
    else:
        form = TaskAssignForm(instance=task)
    
    return render(request, 'projects/task_assign.html', {
        'form': form,
        'task': task
    })
@login_required
def notification_detail(request, pk):
    notification = get_object_or_404(Notification, pk=pk, recipient=request.user)
    
    # تحديث حالة الإشعار كمقروء
    if not notification.is_read:
        notification.is_read = True
        notification.save()
    
    # إذا كان الإشعار متعلق برسالة محادثة
    if notification.notification_type == 'new_message':
        project_id = notification.related_project.id
        return redirect('projects:project_chat', project_id=project_id)
    
    # إذا كان الإشعار متعلق بمهمة
    elif notification.related_task:
        return redirect('projects:task_comments', 
                      project_id=notification.related_task.project.id,
                      task_id=notification.related_task.id)
    
    # في حال لم يكن هناك توجيه محدد
    return redirect('projects:notification_list')

@login_required
def delete_notification(request, pk):
    notification = get_object_or_404(Notification, pk=pk, recipient=request.user)
    notification.delete()
    messages.success(request, 'تم حذف الشعار بنجاح')
    return redirect('projects:notification_list')

@login_required
def delete_all_notifications(request):
    request.user.notifications.all().delete()
    messages.success(request, 'تم حذف جميع الإشعارات بنجاح')
    return redirect('projects:notification_list')

@login_required
def task_rate(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    user_rating = TaskRating.objects.filter(task=task, user=request.user).first()
    
    if request.method == 'POST':
        form = TaskRatingForm(request.POST, instance=user_rating)
        if form.is_valid():
            try:
                rating = form.save(commit=False)
                rating.task = task
                rating.user = request.user
                rating.save()
                
                # إنشاء إشعار للمسؤول عن المهمة
                if task.assigned_to and task.assigned_to != request.user:
                    create_notification(
                        recipient=task.assigned_to,
                        notification_type='rating',
                        title='تقييم جديد على مهمتك',
                        message=f'قام {request.user.get_full_name() or request.user.username} بتقييم المهمة: {task.title} ({rating.get_rating_display()})',
                        related_task=task
                    )
                
                messages.success(request, f'تم حفظ تقييمك ({rating.get_rating_display()}) بنجاح!')
                return redirect('projects:task_comments', project_id=task.project.id, task_id=task.id)
            except Exception as e:
                messages.error(request, f'حدث خطأ أثناء حفظ التقييم: {str(e)}')
        else:
            messages.error(request, 'يرجى التأكد من اختيار تقييم')
    else:
        form = TaskRatingForm(instance=user_rating)
    
    return render(request, 'projects/task_rate.html', {
        'form': form,
        'task': task,
        'user_rating': user_rating
    })

@login_required
def my_tasks(request):
    tasks = Task.objects.filter(assigned_to=request.user)
    today = timezone.now().date()
    
    # البحث والتصفية
    search_query = request.GET.get('search')
    status = request.GET.get('status')
    priority = request.GET.get('priority')
    
    if search_query:
        tasks = tasks.filter(
            Q(title__icontains=search_query) |
            Q(project__name__icontains=search_query)
        )
    if status:
        tasks = tasks.filter(status=status)
    if priority:
        tasks = tasks.filter(priority=priority)
    
    # إضافة حقل الأيام المتبقية
    tasks = tasks.annotate(
        days_remaining=ExpressionWrapper(
            F('due_date') - Value(today),
            output_field=DurationField()
        )
    )
    
    # الإحصائيات والتويعات
    stats = {
        'total_tasks': tasks.count(),
        'completed_tasks': tasks.filter(status='مكتمل').count(),
        'in_progress_tasks': tasks.filter(status='قيد_التنفيذ').count(),
        'overdue_tasks': tasks.filter(due_date__lt=today, status__in=['جديد', 'قيد_لتنفيذ']).count()
    }
    
    status_distribution = list(tasks.values('status').annotate(count=Count('id')))
    priority_distribution = list(tasks.values('priority').annotate(count=Count('id')))
    
    return render(request, 'projects/my_tasks.html', {
        'tasks': tasks,
        'stats': stats,
        'status': status,
        'priority': priority,
        'search_query': search_query,
        'status_distribution': status_distribution,
        'priority_distribution': priority_distribution,
        'today': today
    })

@login_required
def export_my_tasks_to_excel(request):
    tasks = Task.objects.filter(assigned_to=request.user)
    
    # إنشاء ملف Excel جديد
    wb = Workbook()
    ws = wb.active
    ws.title = "مهامي"
    
    # إضافة العاوين
    headers = ['المهمة', 'المشروع', 'الحالة', 'الأولوية', 'اريخ الاسحقاق', 'الأيام المتبقية']
    ws.append(headers)
    
    # إضافة البيانات
    today = timezone.now().date()
    for task in tasks:
        days_remaining = (task.due_date - today).days if task.due_date else None
        row = [
            task.title,
            task.project.name,
            task.get_status_display(),
            task.get_priority_display(),
            task.due_date.strftime('%Y/%m/%d') if task.due_date else '',
            str(days_remaining) if days_remaining is not None else ''
        ]
        ws.append(row)
    
    # تنسي الملف
    for col in ws.columns:
        max_length = 0
        for cell in col:
            max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[get_column_letter(col[0].column)].width = max_length + 2
    
    # إنشاء الاسجابة
    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=my_tasks.xlsx'
    
    wb.save(response)
    return response

@login_required
def task_calendar(request):
    return render(request, 'projects/calendar.html')

@login_required
def calendar_events(request):
    tasks = Task.objects.filter(
        Q(assigned_to=request.user) | 
        Q(project__members=request.user)
    ).distinct().prefetch_related('comments')
    
    events = []
    for task in tasks:
        # تحديد اللون حسب الأولوية
        color = {
            'عالي': '#dc3545',
            'متوسط': '#ffc107',
            'منخفض': '#198754'
        }.get(task.priority, '#3788d8')
        
        # جلب آخر تعليق للمهمة
        latest_comment = task.comments.order_by('-created_at').first()
        
        # تحضير عنوان الحدث
        title = task.title
        if latest_comment:
            title += f"\n- {latest_comment.content[:50]}..." if len(latest_comment.content) > 50 else f"\n- {latest_comment.content}"
        
        event = {
            'id': task.id,
            'title': title,
            'start': task.due_date.strftime('%Y-%m-%d'),
            'allDay': True,
            'backgroundColor': color,
            'borderColor': color,
            'textColor': '#fff',
            'extendedProps': {
                'projectId': task.project.id,
                'projectName': task.project.name,
                'status': task.get_status_display(),
                'priority': task.get_priority_display(),
                'commentsCount': task.comments.count(),
                'assignedTo': task.assigned_to.get_full_name() or task.assigned_to.username
            }
        }
        events.append(event)
    
    return JsonResponse(events, safe=False)

@login_required
def add_attachment(request, task_id):
    task = get_object_or_404(Task, id=task_id)
    
    if request.method == 'POST' and request.FILES.get('file'):
        file = request.FILES['file']
        
        # إنشاء مرق جديد
        attachment = TaskAttachment(
            task=task,
            file=file,
            filename=file.name,
            uploaded_by=request.user,
            file_size=file.size,
            file_type=file.content_type
        )
        attachment.save()
        
        # إنشاء إشعار
        create_notification(
            recipient=task.assigned_to,
            notification_type='task_status',
            title='مرف جديد للمهمة',
            message=f'تم إضافة مرفق جديد للمهمة {task.title}',
            related_task=task
        )
        
        messages.success(request, 'تم رفع الملف بنجاح')
    else:
        messages.error(request, 'حدث خطأ أثناء رفع الملف')
    
    return redirect('projects:task_comments', project_id=task.project.id, task_id=task.id)

@login_required
def delete_attachment(request, task_id, attachment_id):
    attachment = get_object_or_404(TaskAttachment, id=attachment_id, task_id=task_id)
    
    if request.user == attachment.uploaded_by or request.user == attachment.task.project.manager:
        if attachment.file:
            if os.path.exists(attachment.file.path):
                os.remove(attachment.file.path)
        
        attachment.delete()
        messages.success(request, 'تم حذف المرفق بنجاح')
    else:
        messages.error(request, 'ليس لديك صلاحية لحذف هذا المرفق')
    
    return redirect('projects:task_comments', 
                   project_id=attachment.task.project.id, 
                   task_id=attachment.task.id)

@login_required
def project_chat(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    
    # التحقق من صلاحية الوصول
    project_role = ProjectRole.objects.filter(
        project=project,
        user=request.user
    ).first()
    
    if not project_role:
        messages.error(request, 'ليس لديك صلاحية الوصول لهذه المحادثة')
        return redirect('projects:project_list')
    
    chat_room, created = ChatRoom.objects.get_or_create(
        project=project,
        defaults={'name': f"محادثة {project.name}"}
    )
    
    context = {
        'project': project,
        'chat_room': chat_room,
        'messages': Message.objects.filter(chat_room=chat_room).order_by('-created_at')[:50]
    }
    return render(request, 'projects/chat_room.html', context)

@login_required
def send_message(request):
    if request.method == 'POST':
        room_id = request.POST.get('room_id')
        chat_room = get_object_or_404(ChatRoom, id=room_id)
        project = chat_room.project
        
        # التحقق من صلاحية الوصول
        project_role = ProjectRole.objects.filter(
            project=project,
            user=request.user
        ).exists()
        
        if not project_role:
            return JsonResponse({
                'status': 'error',
                'message': 'ليس لديك صلاحية الوصول لهذه المحادثة'
            }, status=403)
        
        content = request.POST.get('content')
        file = request.FILES.get('file')
        
        message = Message.objects.create(
            chat_room=chat_room,
            sender=request.user,
            content=content,
            file=file
        )
        
        # إنشاء إشعارات لجميع أعضاء المشروع ما عدا المرسل
        project_members = ProjectRole.objects.filter(project=project).exclude(user=request.user)
        for member_role in project_members:
            Notification.objects.create(
                recipient=member_role.user,
                notification_type='new_message',
                title='رسالة جديدة في محادثة المشروع',
                message=f'أرسل {request.user.get_full_name() or request.user.username} رسالة في محادثة {project.name}',
                related_project=project
            )
        
        return JsonResponse({
            'status': 'success',
            'message': {
                'id': message.id,
                'content': message.content,
                'sender': message.sender.get_full_name() or message.sender.username,
                'created_at': message.created_at.strftime('%Y-%m-%d %H:%M'),
                'file_url': message.file.url if message.file else None,
                'is_own': True
            }
        })
    return JsonResponse({'status': 'error'}, status=400)

@login_required
def get_messages(request, room_id):
    chat_room = get_object_or_404(ChatRoom, id=room_id)
    project = chat_room.project
    
    # التحقق من صلاحية الوصول
    if not project.members.filter(id=request.user.id).exists():
        return JsonResponse({
            'status': 'error',
            'message': 'ليس لديك صلاحية الوصول'
        }, status=403)
    
    messages = chat_room.messages.all().order_by('-created_at')[:50]
    messages_data = [{
        'id': message.id,
        'content': message.content,
        'sender': message.sender.get_full_name() or message.sender.username,
        'created_at': message.created_at.strftime('%Y-%m-%d %H:%M'),
        'file_url': message.file.url if message.file else None,
        'is_own': message.sender == request.user
    } for message in messages]
    
    return JsonResponse({
        'status': 'success',
        'messages': messages_data
    })

@login_required
def project_edit(request, pk):
    project = get_object_or_404(Project, pk=pk)
    
    # التحقق من صلاحية الوصول
    if not request.user.is_superuser:
        project_role = ProjectRole.objects.filter(
            project=project,
            user=request.user,
            role__in=['مالك', 'مدير']
        ).first()
        
        if not (project_role or project.created_by == request.user):
            messages.error(request, 'ليس لديك صلاحية تعديل هذا المشروع')
            return redirect('projects:project_list')
    
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            try:
                project = form.save()
                messages.success(request, 'تم تحديث المشروع بنجاح!')
                return redirect('projects:project_detail', pk=project.pk)
            except Exception as e:
                messages.error(request, f'حدث خطأ أثناء تحديث المشروع: {str(e)}')
    else:
        form = ProjectForm(instance=project)
    
    return render(request, 'projects/project_form.html', {
        'form': form,
        'title': 'تعديل المشروع',
        'project': project
    })

@login_required
def project_kanban(request, project_id):
    project = get_object_or_404(Project, pk=project_id)
    
    # إضافة الإحصائيات
    stats = {
        'total_tasks': project.tasks.count(),
        'completed_tasks': project.tasks.filter(status='مكتمل').count(),
        'in_progress_tasks': project.tasks.filter(status='قيد التنفيذ').count(),
        'overdue_tasks': project.tasks.filter(due_date__lt=timezone.now().date()).exclude(status='مكتمل').count()
    }
    
    # الحصول على معايير التصفية
    search_query = request.GET.get('search', '')
    priority = request.GET.get('priority', '')
    assigned_to = request.GET.get('assigned_to', '')
    due_date = request.GET.get('due_date', '')
    
    # تصفية المهام لكل حالة
    tasks = {}
    for status in ['جديد', 'قيد التنفيذ', 'معلق', 'مكتمل']:
        filtered_tasks = project.tasks.filter(status=status)
        
        # تطبيق التصفية
        if priority:
            filtered_tasks = filtered_tasks.filter(priority=priority)
        if assigned_to:
            filtered_tasks = filtered_tasks.filter(assigned_to_id=assigned_to)
        if due_date:
            today = timezone.now().date()
            if due_date == 'today':
                filtered_tasks = filtered_tasks.filter(due_date=today)
            elif due_date == 'week':
                week_end = today + timedelta(days=7)
                filtered_tasks = filtered_tasks.filter(due_date__range=[today, week_end])
            elif due_date == 'month':
                month_end = today + timedelta(days=30)
                filtered_tasks = filtered_tasks.filter(due_date__range=[today, month_end])
            elif due_date == 'overdue':
                filtered_tasks = filtered_tasks.filter(due_date__lt=today)
                
        if search_query:
            filtered_tasks = filtered_tasks.filter(
                Q(title__icontains=search_query) |
                Q(description__icontains=search_query)
            )
            
        tasks[status] = filtered_tasks
    
    # تحضير البيانات للرسوم البيانية
    status_distribution = []
    for status in ['جديد', 'قيد التنفيذ', 'معلق', 'مكتمل']:
        count = project.tasks.filter(status=status).count()
        status_distribution.append({'status': status, 'count': count})

    priority_distribution = []
    for priority in ['عالي', 'متوسط', 'منخفض']:
        count = project.tasks.filter(priority=priority).count()
        priority_distribution.append({'priority': priority, 'count': count})
    
    return render(request, 'projects/kanban_board.html', {
        'project': project,
        'tasks': tasks,
        'stats': stats,
        'status_distribution': status_distribution,
        'priority_distribution': priority_distribution,
        'search_query': search_query,
        'priority': priority,
        'assigned_to': assigned_to,
        'due_date': due_date
    })

@login_required
@csrf_exempt
@require_http_methods(["POST"])
def update_task_status(request, task_id):
    try:
        task = Task.objects.get(id=task_id)
        data = json.loads(request.body)
        new_status = data.get('status')
        
        if new_status in ['جديد', 'قيد التنفيذ', 'معلق', 'مكتمل']:
            task.status = new_status
            task.save()
            
            project = task.project
            stats = {
                'total_tasks': project.tasks.count(),
                'completed_tasks': project.tasks.filter(status='مكتمل').count(),
                'in_progress_tasks': project.tasks.filter(status='قيد التنفيذ').count(),
                'overdue_tasks': project.tasks.filter(due_date__lt=timezone.now().date()).exclude(status='مكتمل').count(),
                'new_tasks': project.tasks.filter(status='جديد').count(),
                'pending_tasks': project.tasks.filter(status='معلق').count()
            }
            
            return JsonResponse({
                'success': True,
                'stats': stats,
                'message': 'تم تحديث حالة المهمة بنجاح'
            })
        
        return JsonResponse({
            'success': False,
            'message': 'حالة غير صالحة'
        }, status=400)
        
    except Task.DoesNotExist:
        return JsonResponse({
            'success': False,
            'message': 'المهمة غير موجودة'
        }, status=404)
    except Exception as e:
        return JsonResponse({
            'success': False,
            'message': str(e)
        }, status=500)

