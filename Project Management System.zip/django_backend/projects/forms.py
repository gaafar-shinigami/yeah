from django import forms
from .models import Project, Task, Comment, TaskRating
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User
from django.utils import timezone

class ProjectForm(forms.ModelForm):
    members = forms.ModelMultipleChoiceField(
        queryset=User.objects.all(),
        required=False,
        widget=forms.SelectMultiple(attrs={'class': 'form-control'}),
        label='أعضاء المشروع'
    )

    start_date = forms.DateField(
        required=True,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        label='تاريخ البداية',
        error_messages={'required': 'يجب تحديد تاريخ بداية المشروع'}
    )

    end_date = forms.DateField(
        required=True,
        widget=forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        label='تاريخ النهاية',
        error_messages={'required': 'يجب تحديد تاريخ نهاية المشروع'}
    )

    class Meta:
        model = Project
        fields = ['name', 'description', 'start_date', 'end_date', 'status', 'members']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'status': forms.Select(attrs={'class': 'form-control'}),
        }

    def clean(self):
        cleaned_data = super().clean()
        start_date = cleaned_data.get('start_date')
        end_date = cleaned_data.get('end_date')

        if start_date and end_date and start_date > end_date:
            raise forms.ValidationError('تاريخ البداية يجب أن يكون قبل تاريخ النهاية')

        return cleaned_data

class TaskForm(forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()
        due_date = cleaned_data.get('due_date')
        project = self.instance.project if self.instance.pk else None

        if project and due_date:
            if project.start_date and due_date < project.start_date:
                raise ValidationError('تاريخ استحقاق المهمة يجب أن يكون بعد تاريخ بداية المشروع')
            if project.end_date and due_date > project.end_date:
                raise ValidationError('تاريخ استحقاق المهمة يجب أن يكون قبل تاريخ نهاية المشروع')

        return cleaned_data

    class Meta:
        model = Task
        fields = ['title', 'description', 'assigned_to', 'priority', 'status', 'due_date']
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'عنوان المهمة'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 3,
                'placeholder': 'وصف المهمة'
            }),
            'assigned_to': forms.Select(attrs={
                'class': 'form-control'
            }),
            'priority': forms.Select(attrs={
                'class': 'form-control'
            }),
            'status': forms.Select(attrs={
                'class': 'form-control'
            }),
            'due_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            })
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={
                'rows': 3, 
                'class': 'form-control',
                'placeholder': 'اكتب تعليقك هنا...'
            })
        }

class TaskAssignForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ['assigned_to']
        widgets = {
            'assigned_to': forms.Select(attrs={
                'class': 'form-control',
                'placeholder': 'اختر المسؤول عن المهمة'
            })
        }
        labels = {
            'assigned_to': 'تعيين إلى'
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['assigned_to'].required = False

class TaskRatingForm(forms.ModelForm):
    rating = forms.ChoiceField(
        choices=[
            (5, '★★★★★'),
            (4, '★★★★'),
            (3, '★★★'),
            (2, '★★'),
            (1, '★'),
        ],
        widget=forms.RadioSelect,
        label='التقييم'
    )
    
    class Meta:
        model = TaskRating
        fields = ['rating', 'comment']
        widgets = {
            'comment': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
        }