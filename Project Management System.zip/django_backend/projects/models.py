from django.db import models
from django.contrib.auth.models import User
from django.db.models import Avg
import os
from .permissions import ROLE_PERMISSIONS
from django.utils import timezone

class Project(models.Model):
    STATUS_CHOICES = [
        ('جديد', 'جديد'),
        ('قيد_التنفيذ', 'قيد التنفيذ'),
        ('معلق', 'معلق'),
        ('مكتمل', 'مكتمل'),
    ]
    
    name = models.CharField(max_length=200, verbose_name="اسم المشروع")
    description = models.TextField(verbose_name="وصف المشروع")
    start_date = models.DateField(verbose_name="تاريخ البداية", null=True, blank=True)
    end_date = models.DateField(verbose_name="تاريخ النهاية", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    created_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True,
        blank=True,
        related_name='created_projects', 
        verbose_name="منشئ المشروع"
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='جديد', verbose_name="الحالة")
    members = models.ManyToManyField(User, through='ProjectRole', related_name='projects', verbose_name="الأعضاء")

    class Meta:
        verbose_name = "مشروع"
        verbose_name_plural = "مشاريع"

    def __str__(self):
        return self.name

    def get_progress(self):
        total_tasks = self.tasks.count()
        completed_tasks = self.tasks.filter(status='مكتمل').count()
        return (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0

    def get_user_role(self, user):
        try:
            return self.roles.get(user=user)
        except ProjectRole.DoesNotExist:
            return None

    def has_permission(self, user, permission):
        role = self.get_user_role(user)
        if role:
            return permission in role.permissions
        return False

    def get_status_based_on_dates(self):
        today = timezone.now().date()
        
        if not self.start_date or not self.end_date:
            return self.status
        
        if today < self.start_date:
            return 'جديد'
        elif today > self.end_date:
            return 'مكتمل'
        else:
            return 'قيد_التنفيذ'

class Task(models.Model):
    PRIORITY_CHOICES = [
        ('منخفض', 'منخفض'),
        ('متوسط', 'متوسط'),
        ('عالي', 'عالي'),
    ]
    
    STATUS_CHOICES = [
        ('جديد', 'جديد'),
        ('قيد التنفيذ', 'قيد التنفيذ'),
        ('مراجعة', 'مراجعة'),
        ('مكتمل', 'مكتمل'),
    ]

    title = models.CharField(max_length=200, verbose_name="عنوان المهمة")
    description = models.TextField(verbose_name="وصف المهمة")
    project = models.ForeignKey(
        Project,
        on_delete=models.CASCADE,
        related_name='tasks',
        verbose_name="المشروع"
    )
    assigned_to = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='assigned_tasks',
        verbose_name="مسند إلى"
    )
    priority = models.CharField(
        max_length=20,
        choices=PRIORITY_CHOICES,
        default='متوسط',
        verbose_name="الأولوية"
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='جديد',
        verbose_name="الحالة"
    )
    due_date = models.DateField(verbose_name="تاريخ الاستحقاق")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def average_rating(self):
        return self.ratings.aggregate(Avg('rating'))['rating__avg'] or 0

    class Meta:
        verbose_name = "مهمة"
        verbose_name_plural = "مهام"

    def __str__(self):
        return self.title

class Comment(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='comments', verbose_name="المهمة")
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="الكاتب")
    content = models.TextField(verbose_name="التعليق")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        ordering = ['-created_at']
        verbose_name = "تعليق"
        verbose_name_plural = "التعليقات"

    def __str__(self):
        return f'تعليق من {self.author.get_full_name() or self.author.username}'

class Notification(models.Model):
    NOTIFICATION_TYPES = [
        ('task_assigned', 'تم تعيين مهمة'),
        ('task_updated', 'تم تحديث مهمة'),
        ('task_comment', 'تعليق جديد'),
        ('task_due', 'موعد استحقاق مهمة'),
        ('new_message', 'رسالة جديدة'),
    ]

    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    title = models.CharField(max_length=255)
    message = models.TextField()
    related_task = models.ForeignKey('Task', on_delete=models.CASCADE, null=True, blank=True)
    related_project = models.ForeignKey('Project', on_delete=models.CASCADE, null=True, blank=True)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = 'إشعار'
        verbose_name_plural = 'الإشعارات'

    def __str__(self):
        return f"إشعار لـ {self.recipient.get_full_name() or self.recipient.username}: {self.title}"

class TaskRating(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='ratings', verbose_name='المهمة')
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='المستخدم')
    rating = models.IntegerField(choices=[
        (1, '★'),
        (2, '★★'),
        (3, '★★★'),
        (4, '★★★★'),
        (5, '★★★★★'),
    ], verbose_name='التقييم')
    comment = models.TextField(blank=True, verbose_name='تعليق التقييم')
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='تاريخ التقييم')

    class Meta:
        verbose_name = 'تقييم المهمة'
        verbose_name_plural = 'تقييمات المهام'
        unique_together = ['task', 'user']

class TaskCalendar(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='calendar_events')
    title = models.CharField(max_length=200)
    start = models.DateTimeField()
    end = models.DateTimeField(null=True, blank=True)
    all_day = models.BooleanField(default=True)
    
    def __str__(self):
        return f"تقويم {self.task.title}"

    class Meta:
        verbose_name = 'تقويم المهمة'
        verbose_name_plural = 'تقويم المهام'

class TaskAttachment(models.Model):
    task = models.ForeignKey(Task, on_delete=models.CASCADE, related_name='attachments')
    file = models.FileField(upload_to='task_attachments/%Y/%m/%d/')
    filename = models.CharField(max_length=255)
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    file_size = models.IntegerField()  # بالبايت
    file_type = models.CharField(max_length=100)

    class Meta:
        verbose_name = 'مرفق المهمة'
        verbose_name_plural = 'مرفقات المهام'
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"{self.filename} - {self.task.title}"

    def get_file_size_display(self):
        """عرض حجم الملف بشكل مقروء"""
        size = self.file_size
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def delete(self, *args, **kwargs):
        # حذف الملف لفعلي من نظام الملفات
        if self.file:
            if os.path.exists(self.file.path):
                os.remove(self.file.path)
        super().delete(*args, **kwargs)

class ChatRoom(models.Model):
    name = models.CharField(max_length=255, verbose_name="اسم المحادثة")
    project = models.ForeignKey(Project, on_delete=models.CASCADE, related_name='chat_rooms', verbose_name="المروع")
    members = models.ManyToManyField(User, related_name='chat_rooms', verbose_name="الأعضاء")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإنشاء")
    
    class Meta:
        verbose_name = "غرفة محادثة"
        verbose_name_plural = "غرف امحادثات"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.name} - {self.project.name}"

class Message(models.Model):
    chat_room = models.ForeignKey(
        ChatRoom, 
        on_delete=models.CASCADE, 
        related_name='messages'
    )
    sender = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    file = models.FileField(upload_to='chat_files/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        verbose_name = "رسالة"
        verbose_name_plural = "الرسائل"
        ordering = ['created_at']

    def __str__(self):
        return f"رسالة من {self.sender.get_full_name()} في {self.chat_room.name}"

class ProjectRole(models.Model):
    ROLE_CHOICES = [
        ('مالك', 'مالك المشروع'),
        ('مدير', 'مدير المشروع'),
        ('عضو', 'عضو'),
        ('مراقب', 'مراقب'),
    ]

    project = models.ForeignKey('Project', on_delete=models.CASCADE, related_name='roles')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='project_roles')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='عضو')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "دور المشروع"
        verbose_name_plural = "أدوار المشروع"
        unique_together = ['project', 'user']

    def __str__(self):
        return f"{self.user.get_full_name()} - {self.get_role_display()} في {self.project.name}"

    @property
    def permissions(self):
        return ROLE_PERMISSIONS.get(self.role, [])