def current_project(request):
    """
    يضيف معلومات المشروع الحالي إلى سياق القالب
    """
    project = None
    if 'projects' in request.path:
        try:
            project_id = request.path.split('/')[2]
            if project_id.isdigit():
                from .models import Project
                project = Project.objects.get(pk=int(project_id))
        except (IndexError, Project.DoesNotExist):
            pass
    return {'current_project': project}

def notifications_processor(request):
    if request.user.is_authenticated:
        unread_notifications_count = request.user.notifications.filter(is_read=False).count()
    else:
        unread_notifications_count = 0
    return {'unread_notifications_count': unread_notifications_count}
