from django.db import migrations

def update_existing_projects(apps, schema_editor):
    Project = apps.get_model('projects', 'Project')
    ProjectRole = apps.get_model('projects', 'ProjectRole')
    
    for project in Project.objects.all():
        if not project.created_by:
            # البحث عن مالك المشروع من خلال الأدوار
            owner_role = ProjectRole.objects.filter(
                project=project,
                role='مالك'
            ).first()
            
            if owner_role:
                project.created_by = owner_role.user
                project.save()

class Migration(migrations.Migration):
    dependencies = [
        ('projects', '0005_project_created_by'),
    ]

    operations = [
        migrations.RunPython(update_existing_projects),
    ]