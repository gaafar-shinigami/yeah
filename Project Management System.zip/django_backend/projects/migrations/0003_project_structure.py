from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [
        ('auth', '0012_alter_user_first_name_max_length'),
        ('projects', '0002_chatroom_message'),
    ]

    operations = [
        migrations.CreateModel(
            name='ProjectRole',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('role', models.CharField(choices=[('مالك', 'مالك المشروع'), ('مدير', 'مدير المشروع'), ('عضو', 'عضو'), ('مراقب', 'مراقب')], default='عضو', max_length=20)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('project', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='roles', to='projects.project')),
                ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='project_roles', to='auth.user')),
            ],
            options={
                'verbose_name': 'دور المشروع',
                'verbose_name_plural': 'أدوار المشروع',
                'unique_together': {('project', 'user')},
            },
        ),
        migrations.AddField(
            model_name='project',
            name='created_by',
            field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, related_name='created_projects', to='auth.user', verbose_name='أنشئ بواسطة'),
        ),
        migrations.AddField(
            model_name='project',
            name='owner',
            field=models.ForeignKey(null=True, on_delete=django.db.models.deletion.CASCADE, related_name='owned_projects', to='auth.user', verbose_name='مالك المشروع'),
        ),
        migrations.RemoveField(
            model_name='project',
            name='members',
        ),
        migrations.AddField(
            model_name='project',
            name='members',
            field=models.ManyToManyField(through='projects.ProjectRole', related_name='member_projects', to='auth.user'),
        ),
    ]