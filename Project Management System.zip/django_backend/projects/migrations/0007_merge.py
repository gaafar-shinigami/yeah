from django.db import migrations

class Migration(migrations.Migration):
    dependencies = [
        ('projects', '0006_alter_chatroom_options_remove_project_budget_and_more'),
        ('projects', '0006_update_existing_projects'),
    ]

    operations = [
    ]