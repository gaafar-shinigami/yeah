from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ('projects', '0008_alter_chatroom_options'),
    ]

    operations = [
        migrations.AddField(
            model_name='project',
            name='start_date',
            field=models.DateField(null=True, verbose_name='تاريخ البداية'),
        ),
        migrations.AddField(
            model_name='project',
            name='end_date',
            field=models.DateField(null=True, verbose_name='تاريخ النهاية'),
        ),
    ]