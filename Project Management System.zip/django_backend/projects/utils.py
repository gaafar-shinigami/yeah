def create_notification(recipient, notification_type, title, message, related_task=None, related_project=None):
    """
    وظيفة مساعدة لإنشاء إشعار جديد
    """
    from .models import Notification
    
    notification = Notification.objects.create(
        recipient=recipient,
        notification_type=notification_type,
        title=title,
        message=message,
        related_task=related_task,
        related_project=related_project
    )
    return notification
