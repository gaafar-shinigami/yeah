document.addEventListener('DOMContentLoaded', function() {
    const taskCards = document.querySelectorAll('.task-card');
    const columns = document.querySelectorAll('.kanban-column');

    taskCards.forEach(card => {
        card.addEventListener('dragstart', handleDragStart);
        card.addEventListener('dragend', handleDragEnd);
    });

    columns.forEach(column => {
        column.addEventListener('dragover', handleDragOver);
        column.addEventListener('drop', handleDrop);
    });

    // تحميل قيم التصفية المحفوظة
    const searchQuery = new URLSearchParams(window.location.search).get('search') || '';
    const priority = new URLSearchParams(window.location.search).get('priority') || '';
    
    document.getElementById('searchInput').value = searchQuery;
    document.getElementById('priorityFilter').value = priority;
});

function handleDragStart(e) {
    e.target.classList.add('dragging');
    e.dataTransfer.setData('text/plain', e.target.dataset.taskId);
}

function handleDragEnd(e) {
    e.target.classList.remove('dragging');
}

function handleDragOver(e) {
    e.preventDefault();
}

async function handleDrop(e) {
    e.preventDefault();
    const column = e.target.closest('.kanban-column');
    if (!column) return;

    const taskId = e.dataTransfer.getData('text/plain');
    const newStatus = column.dataset.status;
    const taskCard = document.querySelector(`[data-task-id="${taskId}"]`);
    
    try {
        const csrftoken = getCookie('csrftoken');
        if (!csrftoken) {
            throw new Error('CSRF token not found');
        }

        const response = await fetch(`/projects/tasks/${taskId}/update-status/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken
            },
            body: JSON.stringify({ status: newStatus })
        });

        const data = await response.json();
        
        if (response.ok && data.success) {
            // نقل البطاقة إلى العمود الجديد مباشرة
            column.insertBefore(taskCard, column.firstChild);
            
            // تحديث العدادات والإحصائيات والرسوم البيانية
            updateCounters();
            updateStats(data.stats);
            updateCharts(data.stats);
        } else {
            throw new Error(data.message || 'فشل تحديث حالة المهمة');
        }
    } catch (error) {
        console.error('Error updating task status:', error);
        alert('حدث خطأ أثناء تحديث حالة المهمة');
    }
}

function updateCounters() {
    const columns = document.querySelectorAll('.kanban-column');
    columns.forEach(column => {
        const count = column.querySelectorAll('.task-card').length;
        const badge = column.closest('.card').querySelector('.badge');
        if (badge) {
            badge.textContent = count;
        }
    });
}

function applyFilters() {
    const searchQuery = document.getElementById('searchInput').value;
    const priority = document.getElementById('priorityFilter').value;
    
    // بناء URL مع معايير التصفية
    const url = new URL(window.location.href);
    if (searchQuery) {
        url.searchParams.set('search', searchQuery);
    } else {
        url.searchParams.delete('search');
    }
    
    if (priority) {
        url.searchParams.set('priority', priority);
    } else {
        url.searchParams.delete('priority');
    }
    
    // إعادة تحميل الصفحة مع معايير التصفية
    window.location.href = url.toString();
}

function resetFilters() {
    window.location.href = window.location.pathname;
}

function updateStats(stats) {
    document.querySelector('.bg-primary h3').textContent = stats.total_tasks;
    document.querySelector('.bg-success h3').textContent = stats.completed_tasks;
    document.querySelector('.bg-warning h3').textContent = stats.in_progress_tasks;
    document.querySelector('.bg-danger h3').textContent = stats.overdue_tasks;
}

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

function updateCharts(stats) {
    const statusChart = Chart.getChart('statusChart');
    if (statusChart) {
        // ترتيب ثابت للحالات
        const statusOrder = ['جديد', 'قيد التنفيذ', 'مكتمل', 'معلق'];
        const colors = ['#0d6efd', '#ffc107', '#198754', '#dc3545'];
        
        // تحضير البيانات بنفس الترتيب دائماً
        const newData = statusOrder.map(status => {
            switch(status) {
                case 'جديد': return stats.new_tasks || 0;
                case 'قيد التنفيذ': return stats.in_progress_tasks || 0;
                case 'مكتمل': return stats.completed_tasks || 0;
                case 'معلق': return stats.pending_tasks || 0;
                default: return 0;
            }
        });

        // تحديث البيانات مع الحفاظ على الترتيب
        statusChart.data.labels = statusOrder;
        statusChart.data.datasets[0].backgroundColor = colors;
        statusChart.data.datasets[0].data = newData;
        
        // إضافة خيارات جديدة
        statusChart.options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    rtl: true,
                    labels: {
                        font: {
                            family: 'Cairo',
                            size: 14
                        },
                        padding: 20
                    }
                }
            }
        };
        
        statusChart.update();
    }
}