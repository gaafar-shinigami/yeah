function confirmDelete(event, itemType) {
    if (!confirm(`هل أنت متأكد من حذف هذا ${itemType}؟`)) {
        event.preventDefault();
        return false;
    }
    return true;
}

// تحديث حالة المهمة
function updateTaskStatus(taskId, newStatus) {
    fetch(`/projects/tasks/${taskId}/update-status/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: JSON.stringify({ status: newStatus })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const taskCard = document.querySelector(`[data-task-id="${taskId}"]`);
            const column = document.querySelector(`.kanban-column[data-status="${newStatus}"]`);
            
            if (taskCard && column) {
                const cardBody = column.querySelector('.card-body');
                if (cardBody) {
                    cardBody.appendChild(taskCard);
                    updateCounters();
                }
            }
        }
    })
    .catch(error => {
        console.error('Error updating task status:', error);
        alert('حدث خطأ أثناء تحديث حالة المهمة');
    });
}

// الحصول على CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// تفعيل tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

function toggleAllTasks() {
    var mainCheckbox = document.getElementById('select-all');
    var checkboxes = document.getElementsByClassName('task-checkbox');
    
    for (var checkbox of checkboxes) {
        checkbox.checked = mainCheckbox.checked;
    }
}

function updateCounters() {
    const columns = document.querySelectorAll('.kanban-column');
    columns.forEach(column => {
        const count = column.querySelectorAll('.task-card').length;
        const badge = column.closest('.card').querySelector('.badge');
        if (badge) {
            badge.textContent = count;
        }
    });
}