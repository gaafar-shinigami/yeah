import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = () => {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.get('/api/projects');
        setProjects(response.data);
        setLoading(false);
      } catch (error) {
        console.error('خطأ في جلب المشاريع:', error);
        setLoading(false);
      }
    };

    fetchProjects();
  }, []);

  return (
    <div className="dashboard">
      <h1>لوحة التحكم</h1>
      {loading ? (
        <p>جاري التحميل...</p>
      ) : (
        <div className="projects-grid">
          {projects.map(project => (
            <div key={project._id} className="project-card">
              <h3>{project.name}</h3>
              <p>{project.description}</p>
              <div className="project-status">
                <span>الحالة: {project.status}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Dashboard;